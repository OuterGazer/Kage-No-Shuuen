using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDamagereceiver
{
    void ReceiveDamage(float damage);
}
