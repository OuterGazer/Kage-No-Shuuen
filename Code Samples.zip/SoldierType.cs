using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SoldierType
{
    Runner,
    Tank,
    Elite,
    Coward,
    Daring,
    Guardian
}
